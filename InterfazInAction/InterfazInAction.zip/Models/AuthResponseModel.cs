﻿namespace InterfazInAction.Models
{
    public class AuthResponseModel
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public string Expiration { get; set; }
       
    }
}
